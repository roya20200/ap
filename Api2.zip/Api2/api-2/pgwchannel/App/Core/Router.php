<?php

if (!defined('ROOT'))
{
	include_once('../Views/404.php');
	exit();
}

class Router
{
    public $Routes = array();
    public $CallBacks = array();
	public $Executed = false;

    public function Execute($App)
    {
        $URL = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

        if (in_array($URL, $this->Routes))
        {
            $Key = array_keys($this->Routes, $URL)[0];
            call_user_func($this->CallBacks[$Key]);
			$this->Executed = true;
        }
    }

    public function Call($URL, $CallBack)
    {
        array_push($this->Routes, DOMAIN_ROOT . '/' . $URL);
        array_push($this->CallBacks, $CallBack);
    }
}
