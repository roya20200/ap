<?php

if (!defined('ROOT'))
{
	include_once('../Views/404.php');
	exit();
}

define('DEBUG', true);
error_reporting(E_ALL);

set_error_handler('ErrorHandler');
