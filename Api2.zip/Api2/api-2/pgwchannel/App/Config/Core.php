<?php

if (!defined('ROOT'))
{
	include_once('../Views/404.php');
	exit();
}

define('CONFIG_TRACE_DIRECTORY', ROOT . 'Storage' . DIRECTORY_SEPARATOR, true);
define('DOMAIN_ROOT', '/api-2/pgwchannel');
