<?php

if (!defined('ROOT'))
{
	include_once('404.php');
	exit();
}

$DB = $App->DB();

$RefId = GenerateRandomHexString();
$OrderId = GenerateRandomNumber(9);
$Amount = 10000;

if (isset($_POST['Amount']) && is_int($_POST['Amount']))
	$Amount = intval($_POST['Amount']);

$STMT = $DB->prepare("INSERT INTO `transactions` (`RefId`, `SaleOrderId`, `Amount`) VALUES (?, ?, ?);");
$STMT->bind_param("sii", $RefId, $OrderId, $Amount);
$STMT->execute();
$STMT->close();

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" >
<head>
    <title>در حال اتصال ...</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <style type="text/css">
        #arrow{width:104px;height:70px;position:absolute;left:10px;top:10px;background-image:url('Arrow.png');}
        #main{background-color:#f1f1f1;border:solid 1px #cacaca;width:530px;height:90px;position:absolute;left:50%;margin-left:-265px;top:200px;} 
        #main p{direction:rtl; font-family:Arial;font-size:16px;font-weight:bold;color:#757575;text-align:right;padding-right:60px;line-height:27px;margin-top:30px;}
        #image{width:24px;height:24px; position:absolute;left:100%;margin-left:-35px;top:50%;margin-top:-12px;background-image:url('Loading.gif'); }</style>

    <script type="text/javascript">

        function doPostback() {
                var theForm = document.forms['form1'];
                if (!theForm)
                    theForm = document.form1;
                var GateChanged = document.getElementById("x_GateChanged").value;               
                if (GateChanged == "1")                    
                    {
                        document.getElementById("MainMessage").style.visibility = "hidden";
                        document.getElementById("Warning").style.visibility = "visible";
                        document.getElementById("Message").style.marginTop = "20px";
                        setTimeout(' var theForm = document.forms[\'form1\'];if (!theForm) theForm = document.form1;theForm.submit();', 5000);              
                    }
                else
                    theForm.submit();
           } 

    </script>
</head>
<body onload="doPostback();">
    <form name="form1" method="post" action="<?= DOMAIN_ROOT ?>/startpay.mellat" target="_top" >
		<input id="x_GateChanged" type="hidden" value="0" />
		<input name="RefId" type="hidden" value="<?= $RefId ?>" />
	</form>
    <div id="main">
    <div id="arrow"></div>

        <p id="Message">
            <span id="MainMessage"> درحال اتصال به سرور پرداخت الکترونیک <span style="color: #F37550">ملت<br/></span></span>
            <span id="Warning" style="visibility: hidden; margin-top: 0px; display: block; position: relative; right: -10px; top: -40px; width: 380px;">در حال حاضر ارتباط با سرور بانک مورد نظر شما امکان پذیر نیست، شما به صورت خودکار برای پرداخت به سایت بانک <span style="color: #F37550">ملت</span> منتقل می شوید.</span>
        </p>
    <div id="image"></div>
    </div>
</body>
</html>
