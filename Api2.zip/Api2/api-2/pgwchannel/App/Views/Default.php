<?php
if (!defined('ROOT'))
{
	include_once('404.php');
	exit();
}
?>

<html>
<head>
    
    <META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>دروازه پرداخت اينترنتي به پرداخت ملت</title>
    <link href="<?= DOMAIN_ROOT ?>/css/Style.yui.css" rel="stylesheet" type="text/css">
    <link rel="shortcut icon" href="<?= DOMAIN_ROOT ?>/images/favicon.ico" type="image/x-icon"/>
</head>
<body class="bodyLast">
<form method="post" name="form1">
    <table width="100%">
        <tr>
            <td align="center">
                <table class="NotifyTable">
                    <tr align="center">
                        <td class="InputInfoMainTD">
                            دروازه پرداخت اينترنتي به پرداخت ملت
                        </td>
                    </tr>
                    <tr align="center">
                        <td class="InputInfoHintTD" dir="rtl" style="font-size: 12px;">
                            <br>
                            <b>
                                متاسفانه دسترسی شما به این صفحه امکان پذیر نمی باشد <br>
                                در صورت تمایل به پرداخت، از طریق یکی از فروشگاه های اینترنتی طرف قرارداد شرکت PSP اقدام نمائید.
                            </b>                           &nbsp;  <br>
                            <br>

                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</form>
</body>
</html>